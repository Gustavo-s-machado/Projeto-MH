Font made by http://darhk.tumblr.com/  for askhunters-for-hire.tumblr.com blog
Based on the Font in the Monster Hunter Illustrations 2 art book
Feel free to use!
Credit back.